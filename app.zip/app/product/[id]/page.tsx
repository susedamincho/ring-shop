import { getProductById } from "@/lib/firebase/products"
import ProductDetails from "@/components/product-details"
import RelatedProducts from "@/components/related-products"
import { Product } from "@/lib/firebase/products"

interface ProductPageProps {
  params: Promise<{
    id: string
  }>
}

export default async function ProductPage(props: ProductPageProps) {
  const params = await props.params;
  const productData = await getProductById(params.id)

  if (!productData) {
    return <div>Product not found</div>
  }

  // Ensure the product data matches our Product interface
  const product: Product = {
    id: productData.id,
    name: productData.name || "",
    description: productData.description || "",
    price: productData.price || 0,
    brand: productData.brand,
    model: productData.model,
    storage: productData.storage,
    condition: productData.condition,
    carrier: productData.carrier,
    color: productData.color,
    imeiNumber: productData.imeiNumber,
    batteryHealth: productData.batteryHealth,
    accessories: productData.accessories,
    categoryIds: productData.categoryIds,
    image: productData.image,
    additionalImages: productData.additionalImages,
    createdAt: productData.createdAt instanceof Date
      ? productData.createdAt
      : new Date(((productData.createdAt as any)?.toDate?.() || Date.now())),
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <ProductDetails product={product} />
      <RelatedProducts
        category={product.categoryIds?.[0] || ""}
        categoryId={product.categoryIds?.[0] || ""}
        currentProductId={product.id}
      />
    </div>
  )
}
