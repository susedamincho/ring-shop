import { db } from "./config"
import {
  collection,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  doc,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  Timestamp,
} from "firebase/firestore"

export interface Review {
  id?: string
  productId: string
  userId: string
  userName: string
  rating: number
  comment: string
  createdAt?: any
  updatedAt?: any
}

export interface ReviewsQuery {
  productId?: string
  userId?: string
  limit?: number
  sortBy?: string
  sortDirection?: "asc" | "desc"
}

export async function getReviews(options: ReviewsQuery = {}) {
  try {
    const { productId, userId, sortBy = "createdAt", sortDirection = "desc", limit: queryLimit } = options

    const reviewsQuery = collection(db, "reviews")
    const constraints = []

    if (productId) {
      constraints.push(where("productId", "==", productId))
    }

    if (userId) {
      constraints.push(where("userId", "==", userId))
    }

    constraints.push(orderBy(sortBy, sortDirection))

    if (queryLimit) {
      constraints.push(limit(queryLimit))
    }

    const q = query(reviewsQuery, ...constraints)
    const querySnapshot = await getDocs(q)

    const reviews: Review[] = []
    querySnapshot.forEach((doc) => {
      reviews.push({
        id: doc.id,
        ...doc.data(),
      } as Review)
    })

    return reviews
  } catch (error) {
    console.error("Error getting reviews:", error)
    throw error
  }
}

export async function getReviewById(id: string) {
  try {
    const reviewDoc = await getDoc(doc(db, "reviews", id))

    if (reviewDoc.exists()) {
      return {
        id: reviewDoc.id,
        ...reviewDoc.data(),
      } as Review
    }

    return null
  } catch (error) {
    console.error("Error getting review by ID:", error)
    throw error
  }
}

export async function createReview(review: Review) {
  try {
    const now = Timestamp.now()
    const newReview = {
      ...review,
      createdAt: now,
      updatedAt: now,
    }

    const docRef = await addDoc(collection(db, "reviews"), newReview)
    return {
      id: docRef.id,
      ...newReview,
    }
  } catch (error) {
    console.error("Error creating review:", error)
    throw error
  }
}

export async function updateReview(id: string, review: Partial<Review>) {
  try {
    const reviewRef = doc(db, "reviews", id)
    const updateData = {
      ...review,
      updatedAt: Timestamp.now(),
    }

    await updateDoc(reviewRef, updateData)
    return {
      id,
      ...updateData,
    }
  } catch (error) {
    console.error("Error updating review:", error)
    throw error
  }
}

export async function deleteReview(id: string) {
  try {
    await deleteDoc(doc(db, "reviews", id))
    return true
  } catch (error) {
    console.error("Error deleting review:", error)
    throw error
  }
}
