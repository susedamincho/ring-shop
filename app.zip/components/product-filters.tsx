"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { getCategories, type Category } from "@/lib/firebase/categories"
import { getBrands, type Brand } from "@/lib/firebase/brands"
import { getConditions, getStorageOptions, getCarriers, getColors, type AttributeItem } from "@/lib/firebase/attributes"

interface ProductFiltersProps {
  categoryId?: string
}

interface ActiveFilter {
  type: string
  label: string
  value: string
}

export default function ProductFilters({ categoryId }: ProductFiltersProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isOpen, setIsOpen] = useState(false)
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedBrands, setSelectedBrands] = useState<string[]>([])
  const [selectedConditions, setSelectedConditions] = useState<string[]>([])
  const [selectedStorage, setSelectedStorage] = useState<string[]>([])
  const [selectedCarriers, setSelectedCarriers] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])

  const [categories, setCategories] = useState<Category[]>([])
  const [brands, setBrands] = useState<Brand[]>([])
  const [conditions, setConditions] = useState<AttributeItem[]>([])
  const [storageOptions, setStorageOptions] = useState<AttributeItem[]>([])
  const [carriers, setCarriers] = useState<AttributeItem[]>([])
  const [colors, setColors] = useState<AttributeItem[]>([])

  const [loading, setLoading] = useState(true)
  const [activeFilters, setActiveFilters] = useState<ActiveFilter[]>([])
  const [minPrice, setMinPrice] = useState<string>("")
  const [maxPrice, setMaxPrice] = useState<string>("")

  useEffect(() => {
    const category = searchParams.get("category")
    const brand = searchParams.get("brand")
    const condition = searchParams.get("condition")
    const storage = searchParams.get("storage")
    const carrier = searchParams.get("carrier")
    const color = searchParams.get("color")
    const min = searchParams.get("min")
    const max = searchParams.get("max")

    if (category) setSelectedCategories([category])
    if (brand) setSelectedBrands([brand])
    if (condition) setSelectedConditions([condition])
    if (storage) setSelectedStorage([storage])
    if (carrier) setSelectedCarriers([carrier])
    if (color) setSelectedColors([color])
    if (min) setMinPrice(min)
    if (max) setMaxPrice(max)

    const fetchData = async () => {
      try {
        setLoading(true)
        const [
          fetchedCategories,
          fetchedBrands,
          fetchedConditions,
          fetchedStorageOptions,
          fetchedCarriers,
          fetchedColors,
        ] = await Promise.all([
          getCategories(),
          getBrands(),
          getConditions(),
          getStorageOptions(),
          getCarriers(),
          getColors(),
        ])

        setCategories(fetchedCategories)
        setBrands(fetchedBrands)
        setConditions(fetchedConditions)
        setStorageOptions(fetchedStorageOptions)
        setCarriers(fetchedCarriers)
        setColors(fetchedColors)
      } catch (error) {
        console.error("Error fetching filter data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [searchParams])

  const handleFilterChange = (type: string, value: string) => {
    const newParams = new URLSearchParams(searchParams.toString())

    switch (type) {
      case "category":
        const newCategories = selectedCategories.includes(value)
          ? selectedCategories.filter((c) => c !== value)
          : [...selectedCategories, value]
        setSelectedCategories(newCategories)
        newParams.set("category", newCategories.join(","))
        break
      case "brand":
        const newBrands = selectedBrands.includes(value)
          ? selectedBrands.filter((b) => b !== value)
          : [...selectedBrands, value]
        setSelectedBrands(newBrands)
        newParams.set("brand", newBrands.join(","))
        break
      case "condition":
        const newConditions = selectedConditions.includes(value)
          ? selectedConditions.filter((c) => c !== value)
          : [...selectedConditions, value]
        setSelectedConditions(newConditions)
        newParams.set("condition", newConditions.join(","))
        break
      case "storage":
        const newStorage = selectedStorage.includes(value)
          ? selectedStorage.filter((s) => s !== value)
          : [...selectedStorage, value]
        setSelectedStorage(newStorage)
        newParams.set("storage", newStorage.join(","))
        break
      case "carrier":
        const newCarriers = selectedCarriers.includes(value)
          ? selectedCarriers.filter((c) => c !== value)
          : [...selectedCarriers, value]
        setSelectedCarriers(newCarriers)
        newParams.set("carrier", newCarriers.join(","))
        break
      case "color":
        const newColors = selectedColors.includes(value)
          ? selectedColors.filter((c) => c !== value)
          : [...selectedColors, value]
        setSelectedColors(newColors)
        newParams.set("color", newColors.join(","))
        break
    }

    router.push(`?${newParams.toString()}`)
  }

  const handlePriceChange = (value: number[]) => {
    const newPriceRange = [value[0], value[1]] as [number, number]
    setPriceRange(newPriceRange)
    updateActiveFilters(
      newPriceRange,
      selectedCategories,
      selectedBrands,
      selectedConditions,
      selectedStorage,
      selectedCarriers,
      selectedColors,
    )
  }

  const clearFilters = () => {
    setSelectedCategories([])
    setSelectedBrands([])
    setSelectedConditions([])
    setSelectedStorage([])
    setSelectedCarriers([])
    setSelectedColors([])
    setMinPrice("")
    setMaxPrice("")
    setPriceRange([0, 1000])
    router.push("/products")
  }

  const handleRemoveFilter = (filter: ActiveFilter) => {
    switch (filter.type) {
      case "price":
        setPriceRange([0, 1000])
        break
      case "category":
        setSelectedCategories((prev) => prev.filter((id) => id !== filter.value))
        break
      case "brand":
        setSelectedBrands((prev) => prev.filter((id) => id !== filter.value))
        break
      case "condition":
        setSelectedConditions((prev) => prev.filter((condition) => condition !== filter.value))
        break
      case "storage":
        setSelectedStorage((prev) => prev.filter((storage) => storage !== filter.value))
        break
      case "carrier":
        setSelectedCarriers((prev) => prev.filter((carrier) => carrier !== filter.value))
        break
      case "color":
        setSelectedColors((prev) => prev.filter((color) => color !== filter.value))
        break
    }
  }

  const updateActiveFilters = (
    priceRange: [number, number],
    categoryIds: string[],
    brandIds: string[],
    conditionValues: string[],
    storageValues: string[],
    carrierValues: string[],
    colorValues: string[],
  ) => {
    const filters: ActiveFilter[] = []

    if (priceRange[0] > 0 || priceRange[1] < 1000) {
      filters.push({
        type: "price",
        label: `$${priceRange[0]} - $${priceRange[1]}`,
        value: `${priceRange[0]}-${priceRange[1]}`,
      })
    }

    categoryIds.forEach((id) => {
      const category = categories.find((c) => c.id === id)
      if (category) {
        filters.push({
          type: "category",
          label: category.name,
          value: id,
        })
      }
    })

    brandIds.forEach((id) => {
      const brand = brands.find((b) => b.id === id)
      if (brand) {
        filters.push({
          type: "brand",
          label: brand.name,
          value: id,
        })
      }
    })

    conditionValues.forEach((condition) => {
      filters.push({
        type: "condition",
        label: condition,
        value: condition,
      })
    })

    storageValues.forEach((storage) => {
      filters.push({
        type: "storage",
        label: storage,
        value: storage,
      })
    })

    carrierValues.forEach((carrier) => {
      filters.push({
        type: "carrier",
        label: carrier,
        value: carrier,
      })
    })

    colorValues.forEach((color) => {
      filters.push({
        type: "color",
        label: color,
        value: color,
      })
    })

    setActiveFilters(filters)
  }

  const applyFilters = () => {
    // Create a new URLSearchParams object
    const params = new URLSearchParams()

    // Add price range if not default
    if (priceRange[0] > 0) {
      params.set("minPrice", priceRange[0].toString())
    }
    if (priceRange[1] < 1000) {
      params.set("maxPrice", priceRange[1].toString())
    }

    // Add categories if selected
    if (selectedCategories.length > 0) {
      params.set("categories", selectedCategories.join(","))
    }

    // Add brands if selected
    if (selectedBrands.length > 0) {
      params.set("brands", selectedBrands.join(","))
    }

    // Add conditions if selected
    if (selectedConditions.length > 0) {
      params.set("conditions", selectedConditions.join(","))
    }

    // Add storage options if selected
    if (selectedStorage.length > 0) {
      params.set("storage", selectedStorage.join(","))
    }

    // Add carriers if selected
    if (selectedCarriers.length > 0) {
      params.set("carriers", selectedCarriers.join(","))
    }

    // Add colors if selected
    if (selectedColors.length > 0) {
      params.set("colors", selectedColors.join(","))
    }

    // Preserve search term if it exists
    const search = searchParams.get("search")
    if (search) {
      params.set("search", search)
    }

    // Update the URL with the new params
    const queryString = params.toString()
    router.push(`/products${queryString ? `?${queryString}` : ""}`)

    // Close the filter sheet
    setIsOpen(false)

    // Update active filters display
    updateActiveFilters(
      priceRange,
      selectedCategories,
      selectedBrands,
      selectedConditions,
      selectedStorage,
      selectedCarriers,
      selectedColors,
    )
  }

  const activeFilterCount = activeFilters.length

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 border-dashed">
              <Filter className="mr-2 h-4 w-4" />
              Filter Products
              {activeFilterCount > 0 && (
                <span className="ml-1 rounded-full bg-primary w-5 h-5 text-xs flex items-center justify-center text-primary-foreground">
                  {activeFilterCount}
                </span>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent className="w-[300px] sm:w-[400px] overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Filter Products</SheetTitle>
              <SheetDescription>Narrow down products by applying filters</SheetDescription>
            </SheetHeader>
            <div className="py-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Price Range</h3>
                <div className="px-2">
                  <Slider
                    defaultValue={priceRange}
                    min={0}
                    max={1000}
                    step={10}
                    value={priceRange}
                    onValueChange={(value) => handlePriceChange(value)}
                  />
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm">${priceRange[0]}</span>
                    <span className="text-sm">${priceRange[1]}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Categories</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading categories...</div>
                ) : categories.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No categories available</div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {categories.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category.id}`}
                          checked={selectedCategories.includes(category.id)}
                          onCheckedChange={() => handleFilterChange("category", category.id)}
                        />
                        <Label htmlFor={`category-${category.id}`} className="text-sm font-normal">
                          {category.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Brands</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading brands...</div>
                ) : brands.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No brands available</div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {brands.map((brand) => (
                      <div key={brand.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`brand-${brand.id}`}
                          checked={selectedBrands.includes(brand.id)}
                          onCheckedChange={() => handleFilterChange("brand", brand.id)}
                        />
                        <Label htmlFor={`brand-${brand.id}`} className="text-sm font-normal">
                          {brand.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Condition</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading conditions...</div>
                ) : conditions.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No conditions available</div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {conditions.map((condition) => (
                      <div key={condition.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`condition-${condition.id}`}
                          checked={selectedConditions.includes(condition.name)}
                          onCheckedChange={() => handleFilterChange("condition", condition.name)}
                        />
                        <Label htmlFor={`condition-${condition.id}`} className="text-sm font-normal">
                          {condition.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Storage</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading storage options...</div>
                ) : storageOptions.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No storage options available</div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {storageOptions.map((storage) => (
                      <div key={storage.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`storage-${storage.id}`}
                          checked={selectedStorage.includes(storage.name)}
                          onCheckedChange={() => handleFilterChange("storage", storage.name)}
                        />
                        <Label htmlFor={`storage-${storage.id}`} className="text-sm font-normal">
                          {storage.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Carrier</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading carriers...</div>
                ) : carriers.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No carriers available</div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {carriers.map((carrier) => (
                      <div key={carrier.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`carrier-${carrier.id}`}
                          checked={selectedCarriers.includes(carrier.name)}
                          onCheckedChange={() => handleFilterChange("carrier", carrier.name)}
                        />
                        <Label htmlFor={`carrier-${carrier.id}`} className="text-sm font-normal">
                          {carrier.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Color</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading colors...</div>
                ) : colors.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No colors available</div>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    {colors.map((color) => (
                      <div key={color.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`color-${color.id}`}
                          checked={selectedColors.includes(color.name)}
                          onCheckedChange={() => handleFilterChange("color", color.name)}
                        />
                        <Label htmlFor={`color-${color.id}`} className="text-sm font-normal">
                          {color.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <SheetFooter>
              <SheetTrigger asChild>
                <Button type="submit" onClick={applyFilters}>
                  Apply Filters
                </Button>
              </SheetTrigger>
            </SheetFooter>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  )
}
